package Contact;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {

	//private static final Assert AssertEquals = null;

	//Contact contact = new Contact("1", "firstName", "lastName", "123456789", "1234 Rock Hill Road"); 

	@Test
	void idNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("111111111111", "firstName", "lastName", "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void firstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstNameLong", "lastName", "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void lastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", "lastNameLong", "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void phoneNumberWrongLength() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", "lastName", "12345", "1234 Rock Hill Road");
		});	}
	
	@Test
	void addressTooLong() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", "lastName", "123456789", "12345678909876543212345 Rock Hill Road");
		});	}
	
	@Test
	void idIsNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null , "firstName", "lastName", "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void firstNameIsNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", null, "lastName", "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void lastNameIsNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", null, "123456789", "1234 Rock Hill Road");
		});	}
	
	@Test
	void phoneNumberIsNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", "lastName", null , "1234 Rock Hill Road");
		});	}
	
	@Test
	void addressIsNull() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "firstName", "lastName", "123456789", null);
		});	}
	
	
	@Test
    void getContactID() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
        assertEquals("1", contact.getContactID());
	 }
    
    
    @Test
    public void getFirstName() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
		assertEquals("firstName", contact.getFirstName());
		
    }

    @Test
    void getLastName() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
        assertEquals("lastName", contact.getLastName());
    }

    @Test
    void getPhoneNumber() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
        assertEquals("1234567890", contact.getPhoneNumber());
    }

    @Test
    void getAddress() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
        assertEquals("1234 Rock Hill Road", contact.getAddress());
    }

    @Test
    void testToString() {
        Contact contact = new Contact("1", "firstName", "lastName", "1234567890", "1234 Rock Hill Road");
        assertEquals("Contact [contactID=1, firstName=firstName, lastName=lastName, phoneNumber=1234567890, address=1234 Rock Hill Road]", contact.toString());
    }


}
