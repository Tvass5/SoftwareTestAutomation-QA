package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	
	@Test
	public void testAdd()
	{
	ContactService cs = new ContactService();
	Contact test1 = new Contact("1234500", "Matthew", "Harper", "1111111111", "16 Hope Road");
	assertEquals(true, cs.addContact(test1));
	}
	
	@Test
	public void testDelete()
	{
	ContactService cs = new ContactService();

	Contact test1 = new Contact("1234500", "Matthew", "Harper", "1111111111", "16 Hope Road");
	Contact test2 = new Contact("6789000", "Jessie", "Smith", "2222222222", "Wildwood Crossing");
	Contact test3 = new Contact("0987600", "Danny", "Coltinus", "3333333333", "Stone Mountain lane");

	cs.addContact(test1);
	cs.addContact(test2);
	cs.addContact(test3);

	assertEquals(true, cs.deleteContact("6789000"));
	assertEquals(false, cs.deleteContact("6789001"));
	assertEquals(false, cs.deleteContact("6789000"));
	}

	@Test
	public void testUpdate()
	{
	ContactService cs = new ContactService();

	Contact test1 = new Contact("1234500", "Matthew", "Harper", "1111111111", "16 Hope Road");
	Contact test2 = new Contact("6789000", "Jessie", "Smith", "2222222222", "Wildwood Crossing");
	Contact test3 = new Contact("0987600", "Danny", "Coltinus", "3333333333", "Stone Mountain lane");

	cs.addContact(test1);
	cs.addContact(test2);
	cs.addContact(test3);

	assertEquals(true, cs.updateContact("0987600", "DannyFirst", "ColtinusLast", "3333333333", "Stone Mountain lane"));
	assertEquals(false, cs.updateContact("0987604", "DannyFirst", "ColtinusLast", "3333333333", "Stone Mountain lane"));
	}

	}
